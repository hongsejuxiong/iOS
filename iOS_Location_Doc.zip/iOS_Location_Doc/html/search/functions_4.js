var searchData=
[
  ['initwithcenter_3aradius_3aidentifier_3a',['initWithCenter:radius:identifier:',['../interface_a_map_location_circle_region.html#aa2f4fbd5fde2b643b8f607399525542f',1,'AMapLocationCircleRegion']]],
  ['initwithcoordinates_3acount_3aidentifier_3a',['initWithCoordinates:count:identifier:',['../interface_a_map_location_polygon_region.html#a9282fd06cc8e05a3fa9a4cfd235436e5',1,'AMapLocationPolygonRegion']]],
  ['initwithidentifier_3a',['initWithIdentifier:',['../interface_a_map_location_region.html#a317409b5da050f7f83f3082b87fbe868',1,'AMapLocationRegion']]]
];
